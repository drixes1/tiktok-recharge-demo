TikTok Recharge Coin - Demo
===========================

Bu proje Vite + React + Tailwind ile hazırlanmış demo bir arayüzdür. Gerçek ödeme işlemi içermez.

Hızlı kurulum:
1. Klasöre girin:
   npm install
2. Geliştirme sunucusunu çalıştırın:
   npm run dev
3. Build:
   npm run build

Vercel'e deploy:
- Vercel'de yeni proje oluşturun ve bu klasörü seçin.
- Framework detection: Vite
- Deploy'a tıklayın.

Not: Tema kırmızı renklidir. Tasarım tamamen demo amaçlıdır.
